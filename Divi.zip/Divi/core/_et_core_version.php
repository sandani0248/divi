<?php

// Note, this will be updated automatically during grunt release task3.2.2
$ET_CORE_VERSION = '3.2.2';
